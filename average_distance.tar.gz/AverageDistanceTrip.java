import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AverageTripDistance {

    public static class DistanceMapper
            extends Mapper<Object, Text, Text, DoubleWritable> {

        private final static DoubleWritable distance = new DoubleWritable();
        private Text vendorID = new Text();

        public void map(Object key, Text value, Context context)
                throws IOException, InterruptedException {
            String[] columns = value.toString().split(",");
            if (columns.length >= 6) {
                vendorID.set(columns[0]);
                try {
                    distance.set(Double.parseDouble(columns[4])); // Assuming trip_distance is at index 4
                    context.write(vendorID, distance);
                } catch (NumberFormatException e) {
                    // Handle invalid distance format
                }
            }
        }
    }

    public static class AverageReducer
            extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
        private DoubleWritable result = new DoubleWritable();

        public void reduce(Text key, Iterable<DoubleWritable> values,
                           Context context) throws IOException, InterruptedException {
            int count = 0;
            double totalDistance = 0;

            for (DoubleWritable val : values) {
                totalDistance += val.get();
                count++;
            }

            if (count > 0) {
                double averageDistance = totalDistance / count;
                result.set(averageDistance);
                context.write(key, result);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "average trip distance");
        job.setJarByClass(AverageTripDistance.class);
        job.setMapperClass(DistanceMapper.class);
        // No combiner is needed for averaging
        job.setReducerClass(AverageReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

